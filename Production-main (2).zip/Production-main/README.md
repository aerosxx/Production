



# Production
Production d'aliments par une ferme
Par : -MOSTEFAI Nil-Dany (28718611)
      -28622769 Saïd Bougjdi
      
      
     
     
Hierarchie des classes :


                                                    
                                                    
                                     Fermier--------->              
   --Cereale------->Champ --------------------------->Ferme <---------- (abstract) Animal
   |                                                                              ^   ^
   |                                                                              |   |
   |               (abstract)Produit                                              |   |
   |------------------^  ^    ^ ^------                                           |   |
                         |    |        |                      (abstract)  Volaille     (abstract) Bovin
                         |    |        |                         ^      ^                         ^   ^
                         |    |        |                         |      |                         |   |
                         |    |        |                         |      |                         |   |
                     Viande   Lait    Oeuf                      Coq     Poule                   Boeuf Vache
