public interface Male
{
	public void estTue();	
	public Produit produire();
}
