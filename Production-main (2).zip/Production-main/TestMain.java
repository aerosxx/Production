public class TestMain
{
	public static void main(String[]args)
	{
		Champ c = new Champ(5);
		System.out.println(c.toString());
		c.remplirChamp();
		System.out.println(c.toString());




	}
}
