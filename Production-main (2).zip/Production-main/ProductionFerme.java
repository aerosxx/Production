public class ProductionFerme
{
	public static void main(String[] args)
	{
		Ferme f = new Ferme();
		System.out.println(f.toString());
	}
}
