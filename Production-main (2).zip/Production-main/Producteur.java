public interface Producteur
{
	public Produit produire();
}
